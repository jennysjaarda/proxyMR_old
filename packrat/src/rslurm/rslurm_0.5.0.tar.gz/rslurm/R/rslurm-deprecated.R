#' @title Deprecated functions in package \pkg{rslurm}.
#' @description The functions listed below are deprecated and will be defunct in
#'   the near future. When possible, alternative functions with similar
#'   functionality are also mentioned. Help pages for deprecated functions are
#'   available at \code{help("-deprecated")}.
#' @name rslurm-deprecated
#' @keywords internal
NULL

library(testthat)
library(rslurm)

test_check("rslurm")

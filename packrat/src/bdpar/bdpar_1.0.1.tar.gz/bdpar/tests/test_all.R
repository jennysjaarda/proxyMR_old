library(testthat)
test_check("bdpar")


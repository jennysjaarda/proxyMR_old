#  Version 1.0.1

- Improvements on the structure of the tests. Now taken into account the suggested packages
- Fixed issues caused by archiving the rtweet package

#  Version 1.0.0

- Implement the functionality of the package


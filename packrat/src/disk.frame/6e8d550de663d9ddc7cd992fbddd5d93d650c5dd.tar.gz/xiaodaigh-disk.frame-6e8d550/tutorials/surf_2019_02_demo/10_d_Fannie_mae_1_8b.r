source("inst/fannie_mae/00_setup.r")

fm_with_harp = 
  disk.frame(file.path(outpath, "fm_with_harp"))

fm_with_harp

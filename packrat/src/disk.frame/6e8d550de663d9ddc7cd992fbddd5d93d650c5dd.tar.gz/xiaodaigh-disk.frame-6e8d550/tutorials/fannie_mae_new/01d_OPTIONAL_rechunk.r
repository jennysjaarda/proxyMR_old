library(disk.frame)

fmdf <- disk.frame("fmdf")

rechunk(fmdf, 128)

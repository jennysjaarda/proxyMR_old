context("test-zip_to_disk.frame")

# TODO do some testing
test_that("testing zip_to_disk.frame", {
  expect_true(TRUE)
})


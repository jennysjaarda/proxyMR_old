context("test-print")

setup({
})

test_that("testing print", {
  # TODO proper tests
  expect_equal(2L, 2L)
})


teardown({
  
})
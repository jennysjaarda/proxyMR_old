context("test-RcppExprts")


test_that("testing Rccpexports nothing here", {
  expect_equal(2L, 2L)
})
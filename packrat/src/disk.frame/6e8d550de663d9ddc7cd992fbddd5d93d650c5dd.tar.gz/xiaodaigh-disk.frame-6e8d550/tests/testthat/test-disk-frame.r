context("test-disk.frame")

# TODO add in tests here

test_that("test add_meta", {
  # it works so how to test this?
  expect_equal(2L, 2L)
  
})

test_that("test head", {
  # it works so how to test this?
  expect_equal(2L, 2L)
  
})

test_that("test tail", {
  # it works so how to test this?
  expect_equal(2L, 2L)
  
})


test_that("test nrow", {
  # it works so how to test this?
  
  expect_equal(2L, 2L)
})

test_that("test ncol", {
  # it works so how to test this?
  
  expect_equal(2L, 2L)
})
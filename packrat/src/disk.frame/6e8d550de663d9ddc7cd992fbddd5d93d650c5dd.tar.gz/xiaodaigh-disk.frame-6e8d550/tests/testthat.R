library(testthat)
library(disk.frame)

test_check("disk.frame")

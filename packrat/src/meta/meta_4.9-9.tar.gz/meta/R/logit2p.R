logit2p <- function(x) {
  res <- 1 / (1 + exp(-x))
  res
}

## Test environments
* local OS X install, R 3.6.2
* Ubuntu 14.04.5 LTS (on travis-ci): r-oldrel, r-release, r-devel
* win-builder: r-devel, r-release
* AppVeyor
* rhub:
  * Windows Server 2008 R2 SP1, R-devel, 32/64 bit
  * Ubuntu Linux 16.04 LTS, R-release, GCC
  * Fedora Linux, R-devel, clang, gfortran

## R CMD check results

0 errors | 0 warnings | 0 note

* This is a new release.

## Reverse dependencies
0 packages with problems

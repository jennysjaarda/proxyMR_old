library(testthat)
library(ieugwasr)

test_check("ieugwasr")

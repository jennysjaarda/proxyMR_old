library(testthat)
library(arrangements)
test_check("arrangements")

#ifndef MY_MATH_H__
#define MY_MATH_H__

#include <stdlib.h>

double choose(int n, int k);

double fact(int n);

double fallfact(int n, int k);

double multichoose(int* freq, size_t flen);


#endif /* end of include guard: MY_MATH_H__ */

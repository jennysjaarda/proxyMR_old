library(testthat)
library(taRifx)

test_package("taRifx")
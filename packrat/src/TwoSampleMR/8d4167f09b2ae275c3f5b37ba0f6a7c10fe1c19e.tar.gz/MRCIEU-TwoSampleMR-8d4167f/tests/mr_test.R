load("inst/data/tel.RData")
res <- mr(tel)

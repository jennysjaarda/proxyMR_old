rad2degree <-
function(x) {
  ang <- x*180/pi
  return(ang)
}


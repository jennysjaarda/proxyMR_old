"ones" <-
function(n,p=n) {
   matrix(rep(1,n*p),nrow=n,ncol=p)
}

